import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class LiveApiScreen extends StatefulWidget {
  const LiveApiScreen({Key? key}) : super(key: key);

  @override
  State<LiveApiScreen> createState() => _LiveApiScreenState();
}

class _LiveApiScreenState extends State<LiveApiScreen> {
  final List<String> cities = ['London', 'Dubai', 'Erbil', 'Duhok'];
  final TextEditingController _controller = TextEditingController();
  Map<String, dynamic> weatherData = {};
  Map<String, dynamic> searchedCityWeather = {};

  @override
  void initState() {
    super.initState();
    fetchDefaultCitiesWeather();
  }

  Future<void> fetchDefaultCitiesWeather() async {
    String apiKey = dotenv.env['API_KEY'] ?? '';
    for (String city in cities) {
      final url =
          'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric';
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          weatherData[city] = data;
        });
      } else {
        setState(() {
          weatherData[city] = {'error': 'Error fetching weather'};
        });
      }
    }
  }

  Future<void> fetchCityWeather(String city) async {
    setState(() {
      searchedCityWeather = {}; // Clear previous result
    });

    String apiKey = dotenv.env['API_KEY'] ?? '';
    final url =
        'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        searchedCityWeather[city] = data;
      });
    } else {
      setState(() {
        searchedCityWeather[city] = {'error': 'City not found'};
      });
    }
  }

  Widget buildWeatherCard(String city, dynamic data) {
    if (data == null) {
      return ListTile(title: Text(city), subtitle: const Text("Loading..."));
    } else if (data['error'] != null) {
      return ListTile(title: Text(city), subtitle: Text(data['error']));
    } else {
      double temp = data['main']['temp'];
      String condition = data['weather'][0]['main'];
      return Card(
        margin: const EdgeInsets.all(8),
        child: ListTile(
          leading: Icon(Icons.cloud, color: Colors.blue),
          title: Text(city),
          subtitle: Text("Temp: $temp°C | $condition"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Live Weather")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Enter city name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    final city = _controller.text.trim();
                    if (city.isNotEmpty) {
                      fetchCityWeather(city);
                    }
                  },
                  child: const Text('Search'),
                ),
              ],
            ),
          ),
          if (searchedCityWeather.isNotEmpty)
            ...searchedCityWeather.entries.map(
              (entry) => buildWeatherCard(entry.key, entry.value),
            ),
          const Divider(),
          const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              "Default Cities",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: ListView(
              children: cities
                  .map((city) => buildWeatherCard(city, weatherData[city]))
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}
