import 'package:flutter/material.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('News'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text(
            '🌦️ Weather Update: Heavy Rain Expected Tomorrow\nat your location. Meteorologists predict heavy rainfall across the region starting tomorrow morning. Residents are advised to carry umbrellas and drive safely.',
            style: TextStyle(fontSize: 18, color: Colors.blue),
          ),
          SizedBox(height: 24),
          Text(
            '🌡️ Temperature Alert: Heatwave Continues\nThe ongoing heatwave is expected to last through the weekend, with temperatures reaching up to 40°C. Stay hydrated and avoid outdoor activities during peak hours.',
            style: TextStyle(fontSize: 18, color: Colors.red),
          ),
          SizedBox(height: 24),
          Text(
            '🌬️ Wind Advisory: Strong Winds in the Evening\nStrong winds are forecasted for the evening hours. Secure loose objects outdoors and be cautious while traveling.',
            style: TextStyle(fontSize: 18, color: Colors.green),
          ),
        ],
      ),
    );
  }
}