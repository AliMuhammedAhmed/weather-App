import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About Us'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: const <Widget>[
          SizedBox(height: 10),
          Text(
            'Our app provides real-time weather updates, forecasts, and alerts to keep you informed about the weather conditions in your area. With a user-friendly interface and accurate data, you can plan your day with confidence.',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundImage: AssetImage('assets/images/ai_avatar_1.jpg'), // Your AI-generated image path
                    radius: 25,
                  ),
                  title: Text('Ali Muhammad'),
                  subtitle: Text('Flutter Developer'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Developer of the Application.',
                    style: TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundImage: AssetImage('assets/images/ai_avatar_2.jpg'), // Your AI-generated image path
                    radius: 25,
                  ),
                  title: Text('Sara Ahmed'),
                  subtitle: Text('UI/UX Designer'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Passionate about creating beautiful and user-friendly interfaces.',
                    style: TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundImage: AssetImage('assets/images/ai_avatar_3.jpg'), // Your AI-generated image path
                    radius: 25,
                  ),
                  title: Text('Omar Khalid'),
                  subtitle: Text('Backend Developer'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Focused on building robust and scalable backend systems.',
                    style: TextStyle(fontSize: 16, color: Colors.black87),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text(
              'Short bio about you or the team. You can add more details here about your background, interests, or the team\'s mission.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text(
              'About Our App',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Stay in the know with Our Weather App, the perfect tool to keep you informed about the weather, no matter where you are. With accurate forecasts, real-time updates, and user-friendly features, our app is designed to help you plan your day, week, or even your next adventure—rain or shine.',
            style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
